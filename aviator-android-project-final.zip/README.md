# Aviator Android Lab

Android WebView prototype for automatically observing game WebSocket messages visible to the page.

## Build on GitHub Actions

The included workflow uses Java 17, Gradle 8.9, Android SDK 35 and builds a debug APK.

1. Upload the contents of this project to the GitHub repository root.
2. Open **Actions** → **Build Android APK** → **Run workflow**.
3. After a successful run, download the `aviator-android-lab-debug-apk` artifact.

## Important limitation

The app does not request passwords, OTPs, cookies, auth tokens or payment information, and it does not place or modify bets. WebView JavaScript hooks can only observe WebSocket messages exposed to that page context; some sites use workers, native networking or other mechanisms that WebView JavaScript cannot observe.
