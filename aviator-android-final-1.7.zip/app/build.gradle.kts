plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.aviatorbrowserlab"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.aviatorbrowserlab"
        minSdk = 23
        targetSdk = 35
        versionCode = 17
        versionName = "1.7"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
