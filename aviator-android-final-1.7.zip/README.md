# Aviator Android Lab 1.6

Built directly from the known-good 1.2 project baseline.

## What changed from 1.2

Only local completed-round storage/export was added. The 1.2 WebView/login configuration was intentionally preserved.

The app:
- loads https://jiolottery1.vip/
- observes the same WebSocket messages as the 1.2 build
- records completed round events containing `cmd=84`, a round id (`rbd`), and a multiplier (`mul`)
- stores up to 5,000 completed rounds locally on the device
- displays the newest 30 saved rounds
- exports the saved rounds as CSV through Android's document picker
- can clear the locally saved round list

No passwords, cookies, authentication tokens, payment information, or bets are stored or exported by the round-storage feature.

This is an observation/research tool. Capturing a multiplier stream does not establish that future crash values can be predicted.


Version 1.7 fix: completed-round storage now waits for cmd=84 with sta=3, the observed completed/crash state, so the early 1.00x cmd=84 placeholder is not saved as the final result. If a row already exists for that round, the final multiplier replaces it.
