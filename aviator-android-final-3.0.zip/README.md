# Aviator Signal Lab 3.0

Final research collector for Daman Superstar Aviator.

- Main site: https://damansuperstar1.com/
- Preserves the known-good 1.2 WebView/login configuration.
- Captures WebSocket JSON events and round history.
- Stores pre-crash live trajectory and protocol-field evidence.
- Live Forecast uses only completed historical rounds and current-round information available before the crash.
- Forecast is empirical probability, not a guaranteed exact multiplier predictor.
- EXPORT ALL creates one ZIP with all research CSVs.
- Auth-sensitive fields are redacted.
- No bet placement, credential capture, cookie export, or authentication bypass.

For meaningful validation, collect at least 200 completed rounds and test forecasts chronologically out-of-sample.
