package com.example.aviatorbrowserlab

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.io.File
import java.io.FileOutputStream
import java.io.FileInputStream

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var currentUrl: TextView
    private lateinit var status: TextView
    private lateinit var eventCount: TextView
    private lateinit var roundsView: TextView

    private var count = 0
    private val defaultMainSite = "https://jiolottery1.vip/"
    private val prefs by lazy { getSharedPreferences("aviator_rounds", MODE_PRIVATE) }
    private val rounds = mutableListOf<Round>()
    private var pendingCsv: String = ""
    private var pendingEventCsv: String = ""
    private var currentRoundId: String = ""
    private var currentRoundStartMs: Long = 0L
    private val eventLogFileName = "aviator_live_events.csv"

    data class Round(val roundId: String, val multiplier: String, val timestamp: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        loadRounds()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 12, 12, 12)
        }

        val url = EditText(this).apply {
            setSingleLine(true)
            hint = "Main site URL"
            setText(defaultMainSite)
        }

        val open = Button(this).apply { text = "OPEN MAIN SITE" }

        currentUrl = TextView(this).apply {
            text = "Current URL: -"
            setTextColor(Color.DKGRAY)
            setPadding(4, 4, 4, 4)
        }

        status = TextView(this).apply {
            text = "Status: Waiting…"
            setTextColor(Color.DKGRAY)
            setPadding(4, 4, 4, 4)
        }

        eventCount = TextView(this).apply {
            text = "Events captured: 0"
            setTextColor(Color.DKGRAY)
            setPadding(4, 4, 4, 8)
        }

        val export = Button(this).apply { text = "EXPORT ROUNDS CSV" }
        val exportEvents = Button(this).apply { text = "EXPORT LIVE EVENTS" }
        val clear = Button(this).apply { text = "CLEAR ROUNDS + EVENTS" }

        val buttonRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(export, LinearLayout.LayoutParams(0, -2, 1f))
            addView(exportEvents, LinearLayout.LayoutParams(0, -2, 1f))
            addView(clear, LinearLayout.LayoutParams(0, -2, 1f))
        }

        roundsView = TextView(this).apply {
            setTextColor(Color.DKGRAY)
            setPadding(4, 6, 4, 8)
            textSize = 13f
        }

        web = WebView(this)

        root.addView(url, LinearLayout.LayoutParams(-1, -2))
        root.addView(open, LinearLayout.LayoutParams(-1, -2))
        root.addView(currentUrl, LinearLayout.LayoutParams(-1, -2))
        root.addView(status, LinearLayout.LayoutParams(-1, -2))
        root.addView(eventCount, LinearLayout.LayoutParams(-1, -2))
        root.addView(buttonRow, LinearLayout.LayoutParams(-1, -2))
        root.addView(roundsView, LinearLayout.LayoutParams(-1, -2))
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        renderRounds()

        val s: WebSettings = web.settings
        // Keep the known-good 1.2 WebView configuration unchanged.
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.javaScriptCanOpenWindowsAutomatically = true
        s.setSupportMultipleWindows(false)
        s.userAgentString = s.userAgentString + " AviatorAndroidLab/1.2"

        web.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                super.onPageStarted(view, url, favicon)
                showUrl(url)
                status.text = "Status: Loading…"
                scheduleHook(view)
            }

            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                showUrl(url)
                status.text = "Status: Page loaded; watching for WebSocket events…"
                scheduleHook(view)
            }

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: android.webkit.WebResourceRequest
            ): Boolean {
                showUrl(request.url.toString())
                return false
            }
        }

        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(Bridge(), "AviatorBridge")

        open.setOnClickListener {
            val target = url.text.toString().trim().ifBlank { defaultMainSite }
            web.loadUrl(target)
        }

        export.setOnClickListener { exportCsv() }
        exportEvents.setOnClickListener { exportLiveEventsCsv() }

        clear.setOnClickListener {
            rounds.clear()
            prefs.edit().remove("rounds").apply()
            try { File(filesDir, eventLogFileName).delete() } catch (_: Exception) { }
            currentRoundId = ""
            currentRoundStartMs = 0L
            renderRounds()
            status.text = "Status: Saved rounds and live events cleared."
        }

        web.loadUrl(defaultMainSite)
    }

    private fun showUrl(url: String) {
        runOnUiThread { currentUrl.text = "Current URL: $url" }
    }

    private fun scheduleHook(view: WebView) {
        val handler = android.os.Handler(mainLooper)
        var attempts = 0
        val runnable = object : Runnable {
            override fun run() {
                injectAviatorHook(view)
                attempts++
                if (attempts < 50) handler.postDelayed(this, 200)
            }
        }
        handler.post(runnable)
    }

    private fun injectAviatorHook(view: WebView) {
        val js = """
        (function(){
          try {
            if(window.__aviatorHooked){ return; }
            const OldWS = window.WebSocket;
            if(!OldWS){ return; }
            function report(x){ try{ window.AviatorBridge.event(JSON.stringify(x)); }catch(e){} }
            window.WebSocket = function(url, protocols){
              try{ report({lab:'ws_open', wsUrl:String(url)}); }catch(e){}
              const ws = protocols === undefined ? new OldWS(url) : new OldWS(url, protocols);
              ws.addEventListener('message', function(ev){
                try{
                  const d = typeof ev.data === 'string' ? JSON.parse(ev.data) : null;
                  if(d && (d.cmd===85 || d.cmd===84 || d.cmd===88)) report(d);
                }catch(e){}
              });
              return ws;
            };
            window.WebSocket.prototype = OldWS.prototype;
            window.WebSocket.CONNECTING=OldWS.CONNECTING;
            window.WebSocket.OPEN=OldWS.OPEN;
            window.WebSocket.CLOSING=OldWS.CLOSING;
            window.WebSocket.CLOSED=OldWS.CLOSED;
            window.__aviatorHooked=true;
          } catch(e) {}
        })();
        """.trimIndent()
        view.evaluateJavascript(js, null)
    }

    private fun loadRounds() {
        rounds.clear()
        val raw = prefs.getString("rounds", "[]") ?: "[]"
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                rounds.add(
                    Round(
                        o.optString("roundId"),
                        o.optString("multiplier"),
                        o.optString("timestamp")
                    )
                )
            }
        } catch (_: Exception) {
            rounds.clear()
        }
    }

    private fun saveRounds() {
        val arr = JSONArray()
        rounds.take(5000).forEach { r ->
            arr.put(JSONObject().apply {
                put("roundId", r.roundId)
                put("multiplier", r.multiplier)
                put("timestamp", r.timestamp)
            })
        }
        prefs.edit().putString("rounds", arr.toString()).apply()
    }

    private fun addOrUpdateCompletedRound(roundId: String, multiplier: String) {
        if (roundId.isBlank() || multiplier.isBlank()) return

        val existingIndex = rounds.indexOfFirst { it.roundId == roundId }
        val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())

        if (existingIndex >= 0) {
            // A round can emit an early cmd=84 with 1.00x and a later cmd=84
            // with sta=3 containing the actual crash multiplier. Update the
            // existing row instead of keeping the first 1.00x placeholder.
            rounds[existingIndex] = rounds[existingIndex].copy(
                multiplier = multiplier,
                timestamp = timestamp
            )
        } else {
            rounds.add(0, Round(roundId, multiplier, timestamp))
            if (rounds.size > 5000) rounds.subList(5000, rounds.size).clear()
        }

        saveRounds()
        renderRounds()
    }

    private fun renderRounds() {
        if (!::roundsView.isInitialized) return
        if (rounds.isEmpty()) {
            roundsView.text = "Saved completed rounds (newest first):\nNo completed rounds saved yet."
            return
        }

        val shown = rounds.take(30)
        val sb = StringBuilder("Saved completed rounds (newest first):\n")
        shown.forEach {
            sb.append(it.roundId)
                .append("    ")
                .append(it.multiplier)
                .append("x    ")
                .append(it.timestamp)
                .append('\n')
        }
        if (rounds.size > 30) {
            sb.append("… and ").append(rounds.size - 30).append(" more saved locally.")
        }
        roundsView.text = sb.toString()
    }

    private fun csvText(): String {
        val sb = StringBuilder()
        sb.append("round_id,multiplier,timestamp\n")
        rounds.asReversed().forEach {
            sb.append(csvCell(it.roundId)).append(',')
                .append(csvCell(it.multiplier)).append(',')
                .append(csvCell(it.timestamp)).append('\n')
        }
        return sb.toString()
    }

    private fun csvCell(value: String): String {
        return "\"" + value.replace("\"", "\"\"") + "\""
    }

    private fun ensureEventLog() {
        val file = File(filesDir, eventLogFileName)
        if (!file.exists() || file.length() == 0L) {
            file.writeText("round_id,event_time,elapsed_ms,cmd,sta,multiplier,is_final\n", Charsets.UTF_8)
        }
    }

    private fun appendLiveEvent(
        roundId: String,
        eventTime: String,
        elapsedMs: Long,
        cmd: Int,
        sta: Int,
        multiplier: String,
        isFinal: Boolean
    ) {
        try {
            ensureEventLog()
            val file = File(filesDir, eventLogFileName)
            FileOutputStream(file, true).use { out ->
                val line = listOf(
                    roundId,
                    eventTime,
                    elapsedMs.toString(),
                    cmd.toString(),
                    sta.toString(),
                    multiplier,
                    if (isFinal) "1" else "0"
                ).joinToString(",") { csvCell(it) } + "\n"
                out.write(line.toByteArray(Charsets.UTF_8))
            }
        } catch (_: Exception) { }
    }

    private fun exportLiveEventsCsv() {
        val file = File(filesDir, eventLogFileName)
        if (!file.exists() || file.length() <= 0L) {
            status.text = "Status: No live events captured yet."
            return
        }
        try {
            pendingEventCsv = file.readText(Charsets.UTF_8)
            val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "text/csv"
                putExtra(Intent.EXTRA_TITLE, "aviator_live_events.csv")
            }
            startActivityForResult(intent, 7002)
        } catch (_: Exception) {
            status.text = "Status: Live event export failed."
        }
    }

    private fun exportCsv() {
        if (rounds.isEmpty()) {
            status.text = "Status: No completed rounds to export yet."
            return
        }
        pendingCsv = csvText()
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/csv"
            putExtra(Intent.EXTRA_TITLE, "aviator_rounds.csv")
        }
        startActivityForResult(intent, 7001)
    }

    @Deprecated("Deprecated in Android API; retained for broad device compatibility.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if ((requestCode == 7001 || requestCode == 7002) && resultCode == RESULT_OK) {
            val uri: Uri? = data?.data
            val payload = if (requestCode == 7001) pendingCsv else pendingEventCsv
            if (uri != null) {
                try {
                    contentResolver.openOutputStream(uri)?.use { out ->
                        out.write(payload.toByteArray(Charsets.UTF_8))
                    }
                    status.text = if (requestCode == 7001) {
                        "Status: Rounds CSV exported successfully."
                    } else {
                        "Status: Live events CSV exported successfully."
                    }
                } catch (_: Exception) {
                    status.text = "Status: CSV export failed."
                }
            }
            pendingCsv = ""
            pendingEventCsv = ""
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun event(raw: String) {
            runOnUiThread {
                try {
                    count++
                    eventCount.text = "Events captured: $count"

                    val o = JSONObject(raw)
                    val lab = o.optString("lab", "")
                    if (lab == "ws_open") {
                        status.text = "WebSocket observed: " + o.optString("wsUrl", "-")
                        return@runOnUiThread
                    }

                    val cmd = o.optInt("cmd", -1)
                    val sta = o.optInt("sta", -1)
                    val mul = o.optString("mul", "")
                    val rbd = o.optString("rbd", "")

                    // A non-final cmd=84 carries the round id/state. Use it to associate
                    // subsequent cmd=85 live multiplier updates with the current round.
                    if (cmd == 84 && rbd.isNotBlank() && sta != 3) {
                        if (currentRoundId != rbd) {
                            currentRoundId = rbd
                            currentRoundStartMs = System.currentTimeMillis()
                        }
                    }

                    val eventNow = System.currentTimeMillis()
                    val eventTime = SimpleDateFormat(
                        "yyyy-MM-dd HH:mm:ss.SSS", Locale.US
                    ).format(Date(eventNow))
                    val eventRoundId = if (rbd.isNotBlank()) rbd else currentRoundId
                    val elapsedMs = if (currentRoundStartMs > 0L) {
                        (eventNow - currentRoundStartMs).coerceAtLeast(0L)
                    } else 0L

                    // Store only game-event fields needed for the research dataset.
                    // No URLs, cookies, credentials, auth tokens, or betting data are logged.
                    if (cmd == 85 || cmd == 88 || cmd == 84) {
                        appendLiveEvent(
                            roundId = eventRoundId,
                            eventTime = eventTime,
                            elapsedMs = elapsedMs,
                            cmd = cmd,
                            sta = sta,
                            multiplier = mul,
                            isFinal = (cmd == 84 && sta == 3)
                        )
                    }

                    status.text =
                        "Captured cmd=$cmd  multiplier=${if (mul.isBlank()) "-" else mul + "x"}  round=${if (eventRoundId.isBlank()) "-" else eventRoundId}"

                    // cmd=84, sta=3 is the completed/crash state observed in this
                    // protocol. It is the authoritative final multiplier for the round.
                    if (cmd == 84 && sta == 3 && rbd.isNotBlank() && mul.isNotBlank()) {
                        // If the final event contains the round id, make sure subsequent
                        // timing calculations remain anchored to this round only.
                        if (currentRoundId != rbd) {
                            currentRoundId = rbd
                        }
                        addOrUpdateCompletedRound(rbd, mul)
                        status.text = "Final round saved: $rbd at ${mul}x"
                    }
                } catch (_: Exception) { }
            }
        }
    }
}
