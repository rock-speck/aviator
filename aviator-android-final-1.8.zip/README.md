# Aviator Android Lab 1.8

Built from the known-good 1.7 baseline. The WebView/login configuration is intentionally preserved.

## 1.8 change

Adds automatic local research logging of observed game events:
- `cmd=85` live multiplier updates
- `cmd=84` round state/final result
- `cmd=88` observed game events
- round id, local event timestamp, elapsed milliseconds, command/state, multiplier, and final-event flag

Use **EXPORT LIVE EVENTS** to export `aviator_live_events.csv`.

This is for retrospective statistical analysis of information visible to the client before a completed round. It does not place bets, manipulate the game, bypass authentication, or attempt to predict/alter outcomes in real time.

The event log intentionally excludes URLs, cookies, credentials, auth tokens, and betting/payment data.
