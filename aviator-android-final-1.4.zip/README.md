# Aviator Android Lab 1.3

Android WebView research client for observing game messages exposed to page JavaScript.

Default site: https://jiolottery1.vip/

This version:
- shows the current navigation URL;
- reports WebSocket URLs exposed to page JavaScript;
- reports cmd 84/85/88 events;
- automatically saves each completed round from cmd 84 as `round + multiplier + timestamp`;
- keeps up to 5000 completed rounds locally;
- displays the newest 30 rounds in the app;
- provides an EXPORT CSV button and a CLEAR ROUNDS button.

It does not request passwords, OTPs, cookies, auth tokens, payment information, and it does not place or modify bets.

Important limitation: Android WebView JavaScript cannot guarantee visibility into every WebSocket implementation. Connections created in workers, native code, isolated frames, or other hidden contexts may not be visible. Captured events do not imply that future crash results are predictable.

## Version 1.4 login/network fix
Version 1.4 enables WebView cookies including third-party cookies, removes the WebView marker from the mobile user-agent, enables compatibility handling for mixed content, and reports main-frame network/HTTP errors in the status line. It does not collect or export passwords, cookies, auth tokens, or payment information.
