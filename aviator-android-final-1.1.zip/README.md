# Aviator Android Lab 1.2

Android WebView research client for observing game messages that are exposed to the page.

Default site: https://jiolottery1.vip/

The app automatically displays the current navigation URL, reports WebSocket URLs exposed to page JavaScript, and reports JSON events with cmd 84, 85, or 88 when visible to the page context.

It does not request passwords, OTPs, cookies, auth tokens, payment information, and it does not place or modify bets.

Important limitation: Android WebView JavaScript cannot guarantee visibility into every WebSocket implementation. Connections created in workers, native code, isolated frames, or other hidden contexts may not be visible. Captured events do not imply that future crash results are predictable.
