package com.example.aviatorbrowserlab

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var currentUrl: TextView
    private lateinit var status: TextView
    private lateinit var eventCount: TextView
    private var count = 0

    private val defaultMainSite = "https://jiolottery1.vip/"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 12, 12, 12)
        }
        val url = EditText(this).apply {
            setSingleLine(true)
            hint = "Main site URL"
            setText(defaultMainSite)
        }
        val open = Button(this).apply { text = "OPEN MAIN SITE" }
        currentUrl = TextView(this).apply {
            text = "Current URL: -"
            setTextColor(Color.DKGRAY)
            setPadding(4, 4, 4, 4)
        }
        status = TextView(this).apply {
            text = "Status: Waiting…"
            setTextColor(Color.DKGRAY)
            setPadding(4, 4, 4, 4)
        }
        eventCount = TextView(this).apply {
            text = "Events captured: 0"
            setTextColor(Color.DKGRAY)
            setPadding(4, 4, 4, 8)
        }
        web = WebView(this)

        root.addView(url, LinearLayout.LayoutParams(-1, -2))
        root.addView(open, LinearLayout.LayoutParams(-1, -2))
        root.addView(currentUrl, LinearLayout.LayoutParams(-1, -2))
        root.addView(status, LinearLayout.LayoutParams(-1, -2))
        root.addView(eventCount, LinearLayout.LayoutParams(-1, -2))
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        val s: WebSettings = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.javaScriptCanOpenWindowsAutomatically = true
        s.setSupportMultipleWindows(false)
        s.userAgentString = s.userAgentString + " AviatorAndroidLab/1.2"

        web.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                super.onPageStarted(view, url, favicon)
                showUrl(url)
                status.text = "Status: Loading…"
                scheduleHook(view)
            }

            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                showUrl(url)
                status.text = "Status: Page loaded; watching for WebSocket events…"
                scheduleHook(view)
            }

            override fun shouldOverrideUrlLoading(view: WebView, request: android.webkit.WebResourceRequest): Boolean {
                showUrl(request.url.toString())
                return false
            }
        }
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(Bridge(), "AviatorBridge")

        open.setOnClickListener {
            val target = url.text.toString().trim().ifBlank { defaultMainSite }
            web.loadUrl(target)
        }
        web.loadUrl(defaultMainSite)
    }

    private fun showUrl(url: String) {
        runOnUiThread { currentUrl.text = "Current URL: $url" }
    }

    private fun scheduleHook(view: WebView) {
        val handler = android.os.Handler(mainLooper)
        var attempts = 0
        val runnable = object : Runnable {
            override fun run() {
                injectAviatorHook(view)
                attempts++
                if (attempts < 50) handler.postDelayed(this, 200)
            }
        }
        handler.post(runnable)
    }

    private fun injectAviatorHook(view: WebView) {
        val js = """
        (function(){
          try {
            if(window.__aviatorHooked){ return; }
            const OldWS = window.WebSocket;
            if(!OldWS){ return; }
            function report(x){ try{ window.AviatorBridge.event(JSON.stringify(x)); }catch(e){} }
            window.WebSocket = function(url, protocols){
              try{ report({lab:'ws_open', wsUrl:String(url)}); }catch(e){}
              const ws = protocols === undefined ? new OldWS(url) : new OldWS(url, protocols);
              ws.addEventListener('message', function(ev){
                try{
                  const d = typeof ev.data === 'string' ? JSON.parse(ev.data) : null;
                  if(d && (d.cmd===85 || d.cmd===84 || d.cmd===88)) report(d);
                }catch(e){}
              });
              return ws;
            };
            window.WebSocket.prototype = OldWS.prototype;
            window.WebSocket.CONNECTING=OldWS.CONNECTING;
            window.WebSocket.OPEN=OldWS.OPEN;
            window.WebSocket.CLOSING=OldWS.CLOSING;
            window.WebSocket.CLOSED=OldWS.CLOSED;
            window.__aviatorHooked=true;
          } catch(e) {}
        })();
        """.trimIndent()
        view.evaluateJavascript(js, null)
    }

    inner class Bridge {
        @JavascriptInterface
        fun event(raw: String) {
            runOnUiThread {
                try {
                    count++
                    eventCount.text = "Events captured: $count"
                    val o = JSONObject(raw)
                    val lab = o.optString("lab", "")
                    if (lab == "ws_open") {
                        status.text = "WebSocket observed: " + o.optString("wsUrl", "-")
                        return@runOnUiThread
                    }
                    val cmd = o.optInt("cmd", -1)
                    val mul = o.optString("mul", "")
                    val rbd = o.optString("rbd", "")
                    status.text = "Captured cmd=$cmd  multiplier=${if (mul.isBlank()) "-" else mul + "x"}  round=${if (rbd.isBlank()) "-" else rbd}"
                } catch (_: Exception) { }
            }
        }
    }
}
