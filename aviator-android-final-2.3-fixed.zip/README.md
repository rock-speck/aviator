# Aviator Signal Lab 2.3 — Final Research Collector

This build is based on the known-good 1.2 WebView/login configuration and the 2.1 research collector. It adds a deeper protocol/feature collection layer without storing passwords, cookies, authentication tokens, or payment information.

## Research goals

The collector is designed to test, rather than assume, whether client-visible data contains a reproducible pre-crash signal.

It collects evidence for:

1. Every JSON field observed in captured WebSocket messages.
2. Candidate round-start and configuration messages.
3. Candidate hashes, seeds, nonces, commitments and signatures.
4. Evidence about whether a public/provably-fair mechanism is exposed to the client.
5. Data needed to test whether any client-visible value could mathematically determine the final multiplier.
6. Multiplier velocity.
7. Multiplier acceleration / change in velocity.
8. Trajectory deviation from a per-round log-growth fit.
9. Event/message timing and variation around the ~100 ms cadence.
10. Previous 1–10 completed round multipliers.
11. Low/high/short streak lengths.
12. Current multiplier + trajectory behavior at 1.2x, 1.5x, 2x and 3x.
13. Any other captured protocol fields that may correlate with the eventual result.

## Export files

### `aviator_rounds_v22.csv`
Completed round ID, final multiplier and timestamp.

### `aviator_live_events_v22.csv`
Every parsed JSON WebSocket message captured by the bridge, not only cmd 84/85/88. Authentication-sensitive fields are redacted.

Important fields:
- round_id
- event_time
- elapsed_ms
- sequence
- cmd
- sta
- multiplier
- is_final
- sanitized full JSON payload

### `aviator_round_features_v22.csv`
One row per completed round, including:
- multiplier at 3s, 2s, 1s, 0.5s and 0.25s before crash
- velocity/slope at those windows
- acceleration proxy
- event interval statistics
- event count in final 2 seconds
- threshold-to-crash times for 1.1x/1.2x/1.5x/2x/3x/5x/10x
- previous 10 rounds
- low/high/short streak lengths
- mean/median previous-10 multiplier
- trajectory RMS residual
- log growth rate
- slope at 1.2x/1.5x/2x/3x
- targets for <1.5x, <2x and <3x

### `aviator_protocol_fields_v22.csv`
Flattened field inventory for every parsed JSON message:
- command
- field path
- type
- classification
- value

Classification highlights:
- seed_or_nonce
- hash_or_commit
- signature
- outcome_or_determinant_candidate
- algorithm_or_key_material
- round_or_config

Authentication-sensitive fields such as passwords, cookies and authorization/access/session tokens are replaced with `[REDACTED_AUTH_FIELD]`.

### `aviator_round_protocol_v22.csv`
Per-message protocol map showing:
- cmd/state
- candidate round-start message
- candidate configuration message
- seed/hash/signature indicators
- field names

## Important interpretation rule

A field named `seed`, `hash`, or `signature` is only a candidate. Its presence does NOT prove that it determines the crash point. Later analysis must establish:
- when it becomes visible,
- whether it is known before the crash,
- whether it changes per round,
- whether it can be linked to the final result,
- and whether a documented algorithm maps it to the final multiplier.

Likewise, a statistical correlation is not automatically a prediction signal. Candidate rules should be tested on later unseen rounds.

## UI

The main website remains the primary screen. The LAB panel is hidden by default and can be opened when exporting or checking collection status.

## Collection target

For a serious first pass, collect 500–1,000 consecutive completed rounds. Avoid betting as part of the experiment.

## Build

Use `build-apk-2.3.yml` with GitHub Actions. The workflow uses Java 17, Android API 35/build-tools 35.0.0 and Gradle 8.9, matching the previously successful build setup.


## 2.3 fixes
- EXPORT ALL creates one ZIP containing all research CSVs.
- Existing CSV files get their header repaired instead of retaining malformed legacy headers.
- A foreground collector service reduces Android background process restarts.
- WebView renderer crashes are detected and the site is reloaded.
- The known-good 1.2 WebView/login configuration is preserved.
