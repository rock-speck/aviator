package com.example.aviatorbrowserlab

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var currentUrl: TextView
    private lateinit var status: TextView
    private lateinit var eventCount: TextView
    private lateinit var roundsView: TextView

    private var count = 0
    private val defaultMainSite = "https://jiolottery1.vip/"
    private val prefs by lazy { getSharedPreferences("aviator_rounds", MODE_PRIVATE) }
    private val rounds = mutableListOf<Round>()
    private var pendingCsv: String = ""

    data class Round(val roundId: String, val multiplier: String, val timestamp: String)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        loadRounds()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(12, 12, 12, 12)
        }

        val url = EditText(this).apply {
            setSingleLine(true)
            hint = "Main site URL"
            setText(defaultMainSite)
        }

        val open = Button(this).apply { text = "OPEN MAIN SITE" }

        currentUrl = TextView(this).apply {
            text = "Current URL: -"
            setTextColor(Color.DKGRAY)
            setPadding(4, 4, 4, 4)
        }

        status = TextView(this).apply {
            text = "Status: Waiting…"
            setTextColor(Color.DKGRAY)
            setPadding(4, 4, 4, 4)
        }

        eventCount = TextView(this).apply {
            text = "Events captured: 0"
            setTextColor(Color.DKGRAY)
            setPadding(4, 4, 4, 8)
        }

        val export = Button(this).apply { text = "EXPORT CSV" }
        val clear = Button(this).apply { text = "CLEAR ROUNDS" }

        val buttonRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(export, LinearLayout.LayoutParams(0, -2, 1f))
            addView(clear, LinearLayout.LayoutParams(0, -2, 1f))
        }

        roundsView = TextView(this).apply {
            setTextColor(Color.DKGRAY)
            setPadding(4, 6, 4, 8)
            textSize = 13f
        }

        web = WebView(this)

        root.addView(url, LinearLayout.LayoutParams(-1, -2))
        root.addView(open, LinearLayout.LayoutParams(-1, -2))
        root.addView(currentUrl, LinearLayout.LayoutParams(-1, -2))
        root.addView(status, LinearLayout.LayoutParams(-1, -2))
        root.addView(eventCount, LinearLayout.LayoutParams(-1, -2))
        root.addView(buttonRow, LinearLayout.LayoutParams(-1, -2))
        root.addView(roundsView, LinearLayout.LayoutParams(-1, -2))
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        renderRounds()

        val s: WebSettings = web.settings
        // Keep the known-good 1.2 WebView configuration unchanged.
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.javaScriptCanOpenWindowsAutomatically = true
        s.setSupportMultipleWindows(false)
        s.userAgentString = s.userAgentString + " AviatorAndroidLab/1.2"

        web.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                super.onPageStarted(view, url, favicon)
                showUrl(url)
                status.text = "Status: Loading…"
                scheduleHook(view)
            }

            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                showUrl(url)
                status.text = "Status: Page loaded; watching for WebSocket events…"
                scheduleHook(view)
            }

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: android.webkit.WebResourceRequest
            ): Boolean {
                showUrl(request.url.toString())
                return false
            }
        }

        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(Bridge(), "AviatorBridge")

        open.setOnClickListener {
            val target = url.text.toString().trim().ifBlank { defaultMainSite }
            web.loadUrl(target)
        }

        export.setOnClickListener { exportCsv() }

        clear.setOnClickListener {
            rounds.clear()
            prefs.edit().remove("rounds").apply()
            renderRounds()
            status.text = "Status: Saved rounds cleared."
        }

        web.loadUrl(defaultMainSite)
    }

    private fun showUrl(url: String) {
        runOnUiThread { currentUrl.text = "Current URL: $url" }
    }

    private fun scheduleHook(view: WebView) {
        val handler = android.os.Handler(mainLooper)
        var attempts = 0
        val runnable = object : Runnable {
            override fun run() {
                injectAviatorHook(view)
                attempts++
                if (attempts < 50) handler.postDelayed(this, 200)
            }
        }
        handler.post(runnable)
    }

    private fun injectAviatorHook(view: WebView) {
        val js = """
        (function(){
          try {
            if(window.__aviatorHooked){ return; }
            const OldWS = window.WebSocket;
            if(!OldWS){ return; }
            function report(x){ try{ window.AviatorBridge.event(JSON.stringify(x)); }catch(e){} }
            window.WebSocket = function(url, protocols){
              try{ report({lab:'ws_open', wsUrl:String(url)}); }catch(e){}
              const ws = protocols === undefined ? new OldWS(url) : new OldWS(url, protocols);
              ws.addEventListener('message', function(ev){
                try{
                  const d = typeof ev.data === 'string' ? JSON.parse(ev.data) : null;
                  if(d && (d.cmd===85 || d.cmd===84 || d.cmd===88)) report(d);
                }catch(e){}
              });
              return ws;
            };
            window.WebSocket.prototype = OldWS.prototype;
            window.WebSocket.CONNECTING=OldWS.CONNECTING;
            window.WebSocket.OPEN=OldWS.OPEN;
            window.WebSocket.CLOSING=OldWS.CLOSING;
            window.WebSocket.CLOSED=OldWS.CLOSED;
            window.__aviatorHooked=true;
          } catch(e) {}
        })();
        """.trimIndent()
        view.evaluateJavascript(js, null)
    }

    private fun loadRounds() {
        rounds.clear()
        val raw = prefs.getString("rounds", "[]") ?: "[]"
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                rounds.add(
                    Round(
                        o.optString("roundId"),
                        o.optString("multiplier"),
                        o.optString("timestamp")
                    )
                )
            }
        } catch (_: Exception) {
            rounds.clear()
        }
    }

    private fun saveRounds() {
        val arr = JSONArray()
        rounds.take(5000).forEach { r ->
            arr.put(JSONObject().apply {
                put("roundId", r.roundId)
                put("multiplier", r.multiplier)
                put("timestamp", r.timestamp)
            })
        }
        prefs.edit().putString("rounds", arr.toString()).apply()
    }

    private fun addCompletedRound(roundId: String, multiplier: String) {
        if (roundId.isBlank() || multiplier.isBlank()) return
        if (rounds.any { it.roundId == roundId }) return

        val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        rounds.add(0, Round(roundId, multiplier, timestamp))
        if (rounds.size > 5000) rounds.subList(5000, rounds.size).clear()
        saveRounds()
        renderRounds()
    }

    private fun renderRounds() {
        if (!::roundsView.isInitialized) return
        if (rounds.isEmpty()) {
            roundsView.text = "Saved completed rounds (newest first):\nNo completed rounds saved yet."
            return
        }

        val shown = rounds.take(30)
        val sb = StringBuilder("Saved completed rounds (newest first):\n")
        shown.forEach {
            sb.append(it.roundId)
                .append("    ")
                .append(it.multiplier)
                .append("x    ")
                .append(it.timestamp)
                .append('\n')
        }
        if (rounds.size > 30) {
            sb.append("… and ").append(rounds.size - 30).append(" more saved locally.")
        }
        roundsView.text = sb.toString()
    }

    private fun csvText(): String {
        val sb = StringBuilder()
        sb.append("round_id,multiplier,timestamp\n")
        rounds.asReversed().forEach {
            sb.append(csvCell(it.roundId)).append(',')
                .append(csvCell(it.multiplier)).append(',')
                .append(csvCell(it.timestamp)).append('\n')
        }
        return sb.toString()
    }

    private fun csvCell(value: String): String {
        return "\"" + value.replace("\"", "\"\"") + "\""
    }

    private fun exportCsv() {
        if (rounds.isEmpty()) {
            status.text = "Status: No completed rounds to export yet."
            return
        }
        pendingCsv = csvText()
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "text/csv"
            putExtra(Intent.EXTRA_TITLE, "aviator_rounds.csv")
        }
        startActivityForResult(intent, 7001)
    }

    @Deprecated("Deprecated in Android API; retained for broad device compatibility.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 7001 && resultCode == RESULT_OK) {
            val uri: Uri? = data?.data
            if (uri != null) {
                try {
                    contentResolver.openOutputStream(uri)?.use { out ->
                        out.write(pendingCsv.toByteArray(Charsets.UTF_8))
                    }
                    status.text = "Status: CSV exported successfully."
                } catch (e: Exception) {
                    status.text = "Status: CSV export failed."
                }
            }
            pendingCsv = ""
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun event(raw: String) {
            runOnUiThread {
                try {
                    count++
                    eventCount.text = "Events captured: $count"

                    val o = JSONObject(raw)
                    val lab = o.optString("lab", "")
                    if (lab == "ws_open") {
                        status.text = "WebSocket observed: " + o.optString("wsUrl", "-")
                        return@runOnUiThread
                    }

                    val cmd = o.optInt("cmd", -1)
                    val mul = o.optString("mul", "")
                    val rbd = o.optString("rbd", "")

                    status.text =
                        "Captured cmd=$cmd  multiplier=${if (mul.isBlank()) "-" else mul + "x"}  round=${if (rbd.isBlank()) "-" else rbd}"

                    // cmd=84 is the round-state event. Save only events that contain
                    // both a round id and a multiplier, so live cmd=85 updates are
                    // not mistakenly treated as separate completed rounds.
                    if (cmd == 84 && rbd.isNotBlank() && mul.isNotBlank()) {
                        addCompletedRound(rbd, mul)
                    }
                } catch (_: Exception) { }
            }
        }
    }
}
