# Aviator Android Lab

This is a small Android WebView prototype for observing game messages that are exposed to page JavaScript. It watches cmd 85 live multiplier messages and cmd 84 round-end messages, plus cmd 88.

It does not request passwords, OTPs, cookies, auth tokens, payment details, or place/manipulate bets.

## AndroidIDE
Open this folder as a Gradle project. If AndroidIDE says `./gradlew: No such file or directory`, use the included `gradlew` script or AndroidIDE's Gradle/Build action rather than a missing wrapper command.

If dependency downloads fail, make sure AndroidIDE has Google/Maven Central repositories and the Android SDK platforms/build tools for API 35 installed.
