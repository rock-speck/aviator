Aviator Signal Lab 2.4

Experimental test-signal build based on 2.3. Preserves the known-good WebView/login configuration. Adds an on-screen TEST SIGNAL based on unusually low cmd=85 activity in the last 1 second after the round has been running at least 2.5 seconds. This is an experimental research hint, not a validated crash predictor and not an exact multiplier prediction. Export/background collection from 2.3 is retained.
