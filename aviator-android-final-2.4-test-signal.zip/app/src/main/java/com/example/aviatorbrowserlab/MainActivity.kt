package com.example.aviatorbrowserlab

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sqrt
import kotlin.math.ln
import kotlin.math.pow

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var status: TextView
    private lateinit var compactStats: TextView
    private lateinit var labPanel: LinearLayout
    private lateinit var roundsView: TextView
    private lateinit var signalView: TextView
    private lateinit var urlInput: EditText

    private var count = 0
    private val defaultMainSite = "https://jiolottery1.vip/"
    private val prefs by lazy { getSharedPreferences("aviator_rounds", MODE_PRIVATE) }
    private val rounds = mutableListOf<Round>()
    private val featureRows = mutableListOf<FeatureRow>()
    private val io = Executors.newSingleThreadExecutor()
    private val fileLock = Any()

    private var pendingCsv = ""
    private var pendingEventCsv = ""
    private var pendingFeatureCsv = ""
    private var pendingProtocolCsv = ""
    private var pendingRoundProtocolCsv = ""
    private var pendingAllZip: File? = null

    private var currentRoundId = ""
    private var currentRoundStartMs = 0L
    private var currentMultiplier = ""
    private var currentEvents = 0
    private var packetSeq = 0L
    private var currentTrajectory = mutableListOf<LivePoint>()
    private var sessionRounds = 0
    private val signalEvents = mutableListOf<Pair<Long, Int>>()

    private val eventLogFileName = "aviator_live_events_v22.csv"
    private val featureLogFileName = "aviator_round_features_v22.csv"
    private val protocolFieldLogFileName = "aviator_protocol_fields_v22.csv"
    private val roundProtocolLogFileName = "aviator_round_protocol_v22.csv"
    private val appVersionLabel = "2.3"
    private val MAX_HISTORY = 10

    data class Round(val roundId: String, val multiplier: String, val timestamp: String)
    data class LivePoint(val timeMs: Long, val multiplier: Double)
    data class FeatureRow(
        val roundId: String,
        val finalMultiplier: Double,
        val durationMs: Long,
        val eventCount: Int,
        val at3sBefore: Double?,
        val at2sBefore: Double?,
        val at1sBefore: Double?,
        val at05sBefore: Double?,
        val at025sBefore: Double?,
        val slope3s: Double?,
        val slope2s: Double?,
        val slope1s: Double?,
        val slope05s: Double?,
        val acceleration1s: Double?,
        val lastIntervalMs: Long?,
        val meanIntervalMs: Double?,
        val sdIntervalMs: Double?,
        val eventsLast2s: Int,
        val maxPreCrashMultiplier: Double?,
        val msFrom1_1xToCrash: Long?,
        val msFrom1_2xToCrash: Long?,
        val msFrom1_5xToCrash: Long?,
        val msFrom2xToCrash: Long?,
        val msFrom3xToCrash: Long?,
        val msFrom5xToCrash: Long?,
        val msFrom10xToCrash: Long?,
        val targetLt15: Int,
        val targetLt20: Int,
        val targetLt30: Int,
        val prev1: Double?,
        val prev2: Double?,
        val prev3: Double?,
        val prev4: Double?,
        val prev5: Double?,
        val prev6: Double?,
        val prev7: Double?,
        val prev8: Double?,
        val prev9: Double?,
        val prev10: Double?,
        val lowStreakLt15: Int,
        val highStreakGe5: Int,
        val shortStreakLt2: Int,
        val meanPrev10: Double?,
        val medianPrev10: Double?,
        val trajectoryRmsResidual: Double?,
        val logGrowthRate: Double?,
        val slopeAt1_2x: Double?,
        val slopeAt1_5x: Double?,
        val slopeAt2x: Double?,
        val slopeAt3x: Double?
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadRounds()
        loadFeatureRows()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(246, 248, 250))
        }

        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(12, 8, 8, 8)
            setBackgroundColor(Color.WHITE)
        }

        val title = TextView(this).apply {
            text = "✈ Aviator Signal Lab 2.4 • TEST SIGNAL"
            textSize = 18f
            setTextColor(Color.rgb(25, 35, 45))
            setPadding(4, 6, 8, 6)
        }

        val toggleLab = Button(this).apply { text = "LAB" }
        val refresh = Button(this).apply { text = "↻" }
        topBar.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        topBar.addView(toggleLab, LinearLayout.LayoutParams(-2, -2))
        topBar.addView(refresh, LinearLayout.LayoutParams(-2, -2))
        root.addView(topBar)

        labPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(10, 4, 10, 6)
            setBackgroundColor(Color.WHITE)
        }

        urlInput = EditText(this).apply {
            setSingleLine(true)
            hint = "Main site URL"
            setText(defaultMainSite)
            textSize = 12f
        }
        val open = Button(this).apply { text = "OPEN / RELOAD SITE" }

        compactStats = TextView(this).apply {
            textSize = 12f
            setTextColor(Color.rgb(55, 65, 75))
            setPadding(6, 3, 6, 3)
        }

        signalView = TextView(this).apply {
            text = "TEST SIGNAL • waiting for live round"
            textSize = 13f
            setTypeface(null, android.graphics.Typeface.BOLD)
            setTextColor(Color.rgb(70, 80, 90))
            setPadding(8, 6, 8, 6)
            setBackgroundColor(Color.rgb(235, 238, 242))
        }

        status = TextView(this).apply {
            text = "Ready — open the site and start a round."
            textSize = 12f
            setTextColor(Color.rgb(45, 70, 85))
            setPadding(6, 3, 6, 3)
        }

        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
        }
        val exportRounds = Button(this).apply { text = "ROUNDS CSV" }
        val exportEvents = Button(this).apply { text = "LIVE EVENTS" }
        val exportFeatures = Button(this).apply { text = "FEATURES" }
        val exportAll = Button(this).apply { text = "EXPORT ALL" }
        val exportProtocol = Button(this).apply { text = "FIELDS" }
        val exportRoundProtocol = Button(this).apply { text = "ROUND MAP" }
        val clear = Button(this).apply { text = "CLEAR DATA" }
        buttons.addView(exportRounds, LinearLayout.LayoutParams(0, -2, 1f))
        buttons.addView(exportEvents, LinearLayout.LayoutParams(0, -2, 1f))
        buttons.addView(exportFeatures, LinearLayout.LayoutParams(0, -2, 1f))
        buttons.addView(exportAll, LinearLayout.LayoutParams(0, -2, 1f))
        buttons.addView(clear, LinearLayout.LayoutParams(0, -2, 1f))
        buttons.addView(exportProtocol, LinearLayout.LayoutParams(0, -2, 1f))
        buttons.addView(exportRoundProtocol, LinearLayout.LayoutParams(0, -2, 1f))

        roundsView = TextView(this).apply {
            textSize = 12f
            setTextColor(Color.rgb(65, 75, 85))
            setPadding(6, 4, 6, 4)
        }

        labPanel.addView(urlInput)
        labPanel.addView(open)
        labPanel.addView(compactStats)
        labPanel.addView(signalView)
        labPanel.addView(status)
        labPanel.addView(buttons)
        labPanel.addView(roundsView)

        root.addView(labPanel, LinearLayout.LayoutParams(-1, -2))

        web = WebView(this)
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        if (android.os.Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 9001)
        ensureEventAndFeatureFiles()
        ensureFile(protocolFieldLogFileName, "round_id,event_time,seq,cmd,field_path,field_type,field_class,field_value")
        ensureFile(roundProtocolLogFileName, "round_id,event_time,seq,cmd,sta,multiplier,pre_final,is_round_start_candidate,is_config_candidate,has_seed,has_hash,has_signature,field_names")

        renderUi()
        renderRounds()
        labPanel.visibility = LinearLayout.GONE

        val s: WebSettings = web.settings
        // Preserve the known-good 1.2 login/network configuration.
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.javaScriptCanOpenWindowsAutomatically = true
        s.setSupportMultipleWindows(false)
        s.userAgentString = s.userAgentString + " AviatorAndroidLab/1.2"

        web.webViewClient = object : WebViewClient() {
            override fun onPageStarted(view: WebView, url: String, favicon: android.graphics.Bitmap?) {
                super.onPageStarted(view, url, favicon)
                status.text = "Loading site…"
                scheduleHook(view)
            }

            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                status.text = "Watching live game events…"
                scheduleHook(view)
            }

            override fun shouldOverrideUrlLoading(
                view: WebView,
                request: android.webkit.WebResourceRequest
            ): Boolean = false

            override fun onRenderProcessGone(view: WebView, detail: android.webkit.RenderProcessGoneDetail): Boolean {
                runOnUiThread {
                    status.text = "WebView renderer restarted — reconnecting…"
                    view.postDelayed({
                        try { view.loadUrl(defaultMainSite) } catch (_: Exception) {}
                    }, 800L)
                }
                return true
            }
        }

        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(Bridge(), "AviatorBridge")

        toggleLab.setOnClickListener {
            labPanel.visibility = if (labPanel.visibility == LinearLayout.VISIBLE) {
                toggleLab.text = "LAB"
                LinearLayout.GONE
            } else {
                toggleLab.text = "HIDE"
                LinearLayout.VISIBLE
            }
        }

        refresh.setOnClickListener {
            web.reload()
        }

        open.setOnClickListener {
            val target = urlInput.text.toString().trim().ifBlank { defaultMainSite }
            web.loadUrl(target)
        }

        exportRounds.setOnClickListener { exportRoundsCsv() }
        exportEvents.setOnClickListener { exportLiveEventsCsv() }
        exportFeatures.setOnClickListener { exportFeaturesCsv() }
        exportAll.setOnClickListener { exportAllZip() }
        exportProtocol.setOnClickListener { exportProtocolCsv() }
        exportRoundProtocol.setOnClickListener { exportRoundProtocolCsv() }

        clear.setOnClickListener {
            rounds.clear()
            featureRows.clear()
            prefs.edit().remove("rounds").apply()
            synchronized(fileLock) {
                try { File(filesDir, eventLogFileName).delete() } catch (_: Exception) {}
                try { File(filesDir, featureLogFileName).delete() } catch (_: Exception) {}
                try { File(filesDir, protocolFieldLogFileName).delete() } catch (_: Exception) {}
                try { File(filesDir, roundProtocolLogFileName).delete() } catch (_: Exception) {}
            }
            currentRoundId = ""
            currentRoundStartMs = 0L
            packetSeq = 0L
            currentMultiplier = ""
            currentTrajectory.clear()
            sessionRounds = 0
            renderUi()
            renderRounds()
            status.text = "Data cleared. Collection restarted."
        }

        startKeepAliveService()
        web.loadUrl(defaultMainSite)
    }

    private fun startKeepAliveService() {
        try {
            val intent = Intent(this, CollectorKeepAliveService::class.java)
            if (android.os.Build.VERSION.SDK_INT >= 26) startForegroundService(intent) else startService(intent)
        } catch (_: Exception) {}
    }

    private fun scheduleHook(view: WebView) {
        val handler = android.os.Handler(mainLooper)
        var attempts = 0
        val runnable = object : Runnable {
            override fun run() {
                injectAviatorHook(view)
                attempts++
                if (attempts < 50) handler.postDelayed(this, 200)
            }
        }
        handler.post(runnable)
    }

    private fun injectAviatorHook(view: WebView) {
        val js = """
        (function(){
          try {
            if(window.__aviatorHooked){ return; }
            const OldWS = window.WebSocket;
            if(!OldWS){ return; }
            function report(x){ try{ window.AviatorBridge.event(JSON.stringify(x)); }catch(e){} }
            window.WebSocket = function(url, protocols){
              try{ report({lab:'ws_open', url:String(url).split('?')[0]}); }catch(e){}
              const ws = protocols === undefined ? new OldWS(url) : new OldWS(url, protocols);
              ws.addEventListener('message', function(ev){
                try{
                  if(typeof ev.data !== 'string'){ try{ report({lab:'ws_binary', data_type:Object.prototype.toString.call(ev.data)}); }catch(e){} return; }
                  const d = JSON.parse(ev.data);
                  if(d && typeof d === 'object') report(d);
                }catch(e){}
              });
              return ws;
            };
            window.WebSocket.prototype = OldWS.prototype;
            window.WebSocket.CONNECTING=OldWS.CONNECTING;
            window.WebSocket.OPEN=OldWS.OPEN;
            window.WebSocket.CLOSING=OldWS.CLOSING;
            window.WebSocket.CLOSED=OldWS.CLOSED;
            window.__aviatorHooked=true;
          } catch(e) {}
        })();
        """.trimIndent()
        view.evaluateJavascript(js, null)
    }

    private fun loadRounds() {
        rounds.clear()
        val raw = prefs.getString("rounds", "[]") ?: "[]"
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                rounds.add(Round(o.optString("roundId"), o.optString("multiplier"), o.optString("timestamp")))
            }
        } catch (_: Exception) {}
    }

    private fun saveRounds() {
        val arr = JSONArray()
        rounds.take(5000).forEach {
            arr.put(JSONObject().apply {
                put("roundId", it.roundId)
                put("multiplier", it.multiplier)
                put("timestamp", it.timestamp)
            })
        }
        prefs.edit().putString("rounds", arr.toString()).apply()
    }

    private fun loadFeatureRows() {
        featureRows.clear()
        val file = File(filesDir, featureLogFileName)
        if (!file.exists()) return
        try {
            file.bufferedReader(Charsets.UTF_8).useLines { lines ->
                lines.drop(1).forEach { line ->
                    val p = line.split(",").map { it.trim().trim('"') }
                    if (p.size >= 50) {
                        featureRows.add(FeatureRow(
                            p[0], p[1].toDoubleOrNull() ?: return@forEach, p[2].toLongOrNull() ?: 0L, p[3].toIntOrNull() ?: 0,
                            p[4].toDoubleOrNull(), p[5].toDoubleOrNull(), p[6].toDoubleOrNull(), p[7].toDoubleOrNull(), p[8].toDoubleOrNull(),
                            p[9].toDoubleOrNull(), p[10].toDoubleOrNull(), p[11].toDoubleOrNull(), p[12].toDoubleOrNull(), p[13].toDoubleOrNull(),
                            p[14].toLongOrNull(), p[15].toDoubleOrNull(), p[16].toDoubleOrNull(), p[17].toIntOrNull() ?: 0, p[18].toDoubleOrNull(),
                            p[19].toLongOrNull(), p[20].toLongOrNull(), p[21].toLongOrNull(), p[22].toLongOrNull(), p[23].toLongOrNull(),
                            p[24].toLongOrNull(), p[25].toLongOrNull(), p[26].toIntOrNull() ?: 0, p[27].toIntOrNull() ?: 0, p[28].toIntOrNull() ?: 0,
                            p[29].toDoubleOrNull(), p[30].toDoubleOrNull(), p[31].toDoubleOrNull(), p[32].toDoubleOrNull(), p[33].toDoubleOrNull(),
                            p[34].toDoubleOrNull(), p[35].toDoubleOrNull(), p[36].toDoubleOrNull(), p[37].toDoubleOrNull(), p[38].toDoubleOrNull(),
                            p[39].toIntOrNull() ?: 0, p[40].toIntOrNull() ?: 0, p[41].toIntOrNull() ?: 0, p[42].toDoubleOrNull(), p[43].toDoubleOrNull(),
                            p[44].toDoubleOrNull(), p[45].toDoubleOrNull(), p[46].toDoubleOrNull(), p[47].toDoubleOrNull(), p[48].toDoubleOrNull(), p[49].toDoubleOrNull()
                        ))
                    }
                }
            }
        } catch (_: Exception) {}
        if (featureRows.size > 10000) {
            val keep = featureRows.takeLast(10000)
            featureRows.clear(); featureRows.addAll(keep)
        }
    }

    private fun ensureFile(fileName: String, header: String) {
        synchronized(fileLock) {
            val f = File(filesDir, fileName)
            if (!f.exists() || f.length() == 0L) {
                f.writeText(header + "\n", Charsets.UTF_8)
                return
            }
            try {
                val first = f.bufferedReader(Charsets.UTF_8).use { it.readLine() } ?: ""
                if (first == header) return
                val tmp = File(filesDir, fileName + ".tmp")
                f.inputStream().bufferedReader(Charsets.UTF_8).use { reader ->
                    tmp.outputStream().bufferedWriter(Charsets.UTF_8).use { writer ->
                        writer.append(header).append('\n')
                        reader.readLine()
                        reader.forEachLine { line -> writer.append(line).append('\n') }
                    }
                }
                if (tmp.renameTo(f)) return
                tmp.delete()
            } catch (_: Exception) {}
        }
    }

    private fun normalizedCsv(file: File, header: String): String {
        if (!file.exists() || file.length() == 0L) return ""
        return try {
            val text = file.readText(Charsets.UTF_8)
            val firstNl = text.indexOf('\n')
            if (firstNl < 0) header + "\n"
            else header + "\n" + text.substring(firstNl + 1)
        } catch (_: Exception) { "" }
    }

    private fun appendLine(fileName: String, line: String) {
        io.execute {
            synchronized(fileLock) {
                try {
                    FileOutputStream(File(filesDir, fileName), true).use {
                        it.write((line + "\n").toByteArray(Charsets.UTF_8))
                    }
                } catch (_: Exception) {}
            }
        }
    }

    private fun addOrUpdateCompletedRound(roundId: String, multiplier: String) {
        if (roundId.isBlank() || multiplier.isBlank()) return
        val index = rounds.indexOfFirst { it.roundId == roundId }
        val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
        if (index >= 0) {
            rounds[index] = rounds[index].copy(multiplier = multiplier, timestamp = timestamp)
        } else {
            rounds.add(0, Round(roundId, multiplier, timestamp))
            if (rounds.size > 5000) rounds.subList(5000, rounds.size).clear()
        }
        saveRounds()
        sessionRounds++
        renderUi()
        renderRounds()
    }

    private fun renderUi() {
        if (!::compactStats.isInitialized) return
        val saved = rounds.size
        compactStats.text =
            "Rounds: $saved  •  Session: $sessionRounds  •  Events: $count  •  Current: " +
            (if (currentMultiplier.isBlank()) "—" else currentMultiplier + "×") +
            "  •  Round: " + (if (currentRoundId.isBlank()) "—" else currentRoundId)
    }

    private fun renderRounds() {
        if (!::roundsView.isInitialized) return
        if (rounds.isEmpty()) {
            roundsView.text = "Saved rounds: 0  •  Use ROUNDS CSV to export history."
            return
        }
        val last = rounds.take(8).joinToString("   ") { "${it.roundId}: ${it.multiplier}×" }
        roundsView.text = "Saved rounds: ${rounds.size}  •  Latest: $last"
    }

    private fun csvCell(value: String): String = "\"" + value.replace("\"", "\"\"") + "\""

    private fun roundsCsv(): String {
        val sb = StringBuilder("round_id,multiplier,timestamp\n")
        rounds.asReversed().forEach {
            sb.append(csvCell(it.roundId)).append(',')
                .append(csvCell(it.multiplier)).append(',')
                .append(csvCell(it.timestamp)).append('\n')
        }
        return sb.toString()
    }

    private fun featureCsv(): String {
        val sb = StringBuilder(
            "round_id,final_multiplier,duration_ms,event_count,at_3s_before,at_2s_before,at_1s_before,at_0_5s_before,at_0_25s_before," +
            "slope_3s,slope_2s,slope_1s,slope_0_5s,acceleration_1s,last_interval_ms,mean_interval_ms,sd_interval_ms," +
            "events_last_2s,max_precrash_multiplier,ms_from_1_1x_to_crash,ms_from_1_2x_to_crash,ms_from_1_5x_to_crash," +
            "ms_from_2x_to_crash,ms_from_3x_to_crash,ms_from_5x_to_crash,ms_from_10x_to_crash,target_lt_1_5,target_lt_2,target_lt_3," +
            "prev1,prev2,prev3,prev4,prev5,prev6,prev7,prev8,prev9,prev10,low_streak_lt_1_5,high_streak_ge_5,short_streak_lt_2,mean_prev10,median_prev10,trajectory_rms_residual,log_growth_rate,slope_at_1_2x,slope_at_1_5x,slope_at_2x,slope_at_3x\n"
        )
        featureRows.forEach { f ->
            val values = listOf(f.roundId,f.finalMultiplier,f.durationMs,f.eventCount,f.at3sBefore,f.at2sBefore,f.at1sBefore,f.at05sBefore,f.at025sBefore,
                f.slope3s,f.slope2s,f.slope1s,f.slope05s,f.acceleration1s,f.lastIntervalMs,f.meanIntervalMs,f.sdIntervalMs,f.eventsLast2s,f.maxPreCrashMultiplier,
                f.msFrom1_1xToCrash,f.msFrom1_2xToCrash,f.msFrom1_5xToCrash,f.msFrom2xToCrash,f.msFrom3xToCrash,f.msFrom5xToCrash,f.msFrom10xToCrash,
                f.targetLt15,f.targetLt20,f.targetLt30,f.prev1,f.prev2,f.prev3,f.prev4,f.prev5,f.prev6,f.prev7,f.prev8,f.prev9,f.prev10,
                f.lowStreakLt15,f.highStreakGe5,f.shortStreakLt2,f.meanPrev10,f.medianPrev10,f.trajectoryRmsResidual,f.logGrowthRate,
                f.slopeAt1_2x,f.slopeAt1_5x,f.slopeAt2x,f.slopeAt3x)
            sb.append(values.joinToString(",") { csvCell(it?.toString() ?: "") }).append('\n')
        }
        return sb.toString()
    }

    private fun ensureEventAndFeatureFiles() {
        ensureFile(eventLogFileName,
            "round_id,event_time,elapsed_ms,seq,cmd,sta,multiplier,is_final,selected_payload")
        ensureFile(featureLogFileName,
            "round_id,final_multiplier,duration_ms,event_count,at_3s_before,at_2s_before,at_1s_before,at_0_5s_before,at_0_25s_before," +
            "slope_3s,slope_2s,slope_1s,slope_0_5s,acceleration_1s,last_interval_ms,mean_interval_ms,sd_interval_ms," +
            "events_last_2s,max_precrash_multiplier,ms_from_1_1x_to_crash,ms_from_1_2x_to_crash,ms_from_1_5x_to_crash," +
            "ms_from_2x_to_crash,ms_from_3x_to_crash,ms_from_5x_to_crash,ms_from_10x_to_crash,target_lt_1_5,target_lt_2,target_lt_3," +
            "prev1,prev2,prev3,prev4,prev5,prev6,prev7,prev8,prev9,prev10,low_streak_lt_1_5,high_streak_ge_5,short_streak_lt_2,mean_prev10,median_prev10,trajectory_rms_residual,log_growth_rate,slope_at_1_2x,slope_at_1_5x,slope_at_2x,slope_at_3x")
    }

    private fun exportRoundsCsv() {
        if (rounds.isEmpty()) { status.text = "No completed rounds yet."; return }
        pendingCsv = roundsCsv()
        startCreateDocument("aviator_rounds.csv", "text/csv", 7001)
    }

    private fun exportLiveEventsCsv() {
        io.execute {
            synchronized(fileLock) {
                val file = File(filesDir, eventLogFileName)
                runOnUiThread {
                    if (!file.exists() || file.length() <= 0L) {
                        status.text = "No live events captured yet."
                    } else {
                        try {
                            pendingEventCsv = normalizedCsv(file, "round_id,event_time,elapsed_ms,seq,cmd,sta,multiplier,is_final,selected_payload")
                            startCreateDocument("aviator_live_events_v22.csv", "text/csv", 7002)
                        } catch (_: Exception) { status.text = "Live event export failed." }
                    }
                }
            }
        }
    }

    private fun exportFeaturesCsv() {
        if (featureRows.isEmpty()) { status.text = "No completed feature rows yet."; return }
        pendingFeatureCsv = featureCsv()
        startCreateDocument("aviator_round_features_v22.csv", "text/csv", 7003)
    }


    private fun exportAllZip() {
        status.text = "Preparing research ZIP…"
        io.execute {
            try {
                val zipFile = File(cacheDir, "aviator_signal_lab_2.3_export.zip")
                ZipOutputStream(zipFile.outputStream().buffered()).use { zip ->
                    fun addText(name: String, text: String) {
                        zip.putNextEntry(ZipEntry(name))
                        zip.write(text.toByteArray(Charsets.UTF_8))
                        zip.closeEntry()
                    }
                    addText("aviator_rounds.csv", roundsCsv())
                    addText("aviator_live_events_v22.csv", normalizedCsv(File(filesDir, eventLogFileName), "round_id,event_time,elapsed_ms,seq,cmd,sta,multiplier,is_final,selected_payload"))
                    addText("aviator_round_features_v22.csv", featureCsv())
                    addText("aviator_protocol_fields_v22.csv", protocolCsv())
                    addText("aviator_round_protocol_v22.csv", roundProtocolCsv())
                    addText("README.txt", "Aviator Signal Lab 2.3 research export\nContains collected rounds, live events, round features, protocol fields, and round protocol map.\n")
                }
                runOnUiThread {
                    pendingAllZip = zipFile
                    startCreateDocument("aviator_signal_lab_2.3_export.zip", "application/zip", 7006)
                }
            } catch (_: Exception) {
                runOnUiThread { status.text = "EXPORT ALL failed while preparing ZIP." }
            }
        }
    }

    private fun protocolCsv(): String {
        val file = File(filesDir, protocolFieldLogFileName)
        return normalizedCsv(file, "round_id,event_time,seq,cmd,field_path,field_type,field_class,field_value")
    }

    private fun roundProtocolCsv(): String {
        val file = File(filesDir, roundProtocolLogFileName)
        return normalizedCsv(file, "round_id,event_time,seq,cmd,sta,multiplier,pre_final,is_round_start_candidate,is_config_candidate,has_seed,has_hash,has_signature,field_names")
    }

    private fun exportProtocolCsv() {
        io.execute {
            synchronized(fileLock) {
                val payload = protocolCsv()
                runOnUiThread {
                    if (payload.isBlank()) status.text = "No protocol fields captured yet."
                    else {
                        pendingProtocolCsv = payload
                        startCreateDocument("aviator_protocol_fields_v22.csv", "text/csv", 7004)
                    }
                }
            }
        }
    }

    private fun exportRoundProtocolCsv() {
        io.execute {
            synchronized(fileLock) {
                val payload = roundProtocolCsv()
                runOnUiThread {
                    if (payload.isBlank()) status.text = "No round protocol map captured yet."
                    else {
                        pendingRoundProtocolCsv = payload
                        startCreateDocument("aviator_round_protocol_v22.csv", "text/csv", 7005)
                    }
                }
            }
        }
    }

    private fun isAuthSensitiveKey(key: String): Boolean {
        val k = key.lowercase(Locale.US)
        return listOf(
            "password", "passwd", "cookie", "authorization", "access_token", "refresh_token",
            "session_token", "id_token", "auth_token", "bearer", "csrf", "xsrf"
        ).any { k.contains(it) } || k == "token"
    }

    private fun fieldClass(key: String): String {
        val k = key.lowercase(Locale.US)
        return when {
            listOf("seed", "nonce").any { k.contains(it) } -> "seed_or_nonce"
            listOf("hash", "sha", "md5", "digest", "commit").any { k.contains(it) } -> "hash_or_commit"
            k.contains("signature") || k == "sig" -> "signature"
            listOf("serverseed", "clientseed", "outcome", "crashpoint", "crash_point", "result", "random", "multiplier").any { k.contains(it) } -> "outcome_or_determinant_candidate"
            listOf("rsa", "algorithm", "publickey", "public_key", "verify", "salt").any { k.contains(it) } -> "algorithm_or_key_material"
            listOf("config", "state", "status", "round", "rbd").any { k.contains(it) } -> "round_or_config"
            else -> ""
        }
    }

    private fun appendFlattenedFields(value: Any?, path: String, out: MutableList<Pair<String, String>>) {
        when (value) {
            is JSONObject -> {
                val keys = value.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    appendFlattenedFields(value.opt(k), if (path.isBlank()) k else "$path.$k", out)
                }
            }
            is JSONArray -> {
                if (value.length() == 0) out.add(path to "[]")
                else out.add(path to value.toString())
            }
            null, JSONObject.NULL -> out.add(path to "")
            else -> out.add(path to value.toString())
        }
    }


    private fun sanitizeJson(value: Any?): Any? {
        return when (value) {
            is JSONObject -> {
                val out = JSONObject()
                val keys = value.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    out.put(k, if (isAuthSensitiveKey(k)) "[REDACTED_AUTH_FIELD]" else sanitizeJson(value.opt(k)))
                }
                out
            }
            is JSONArray -> {
                val out = JSONArray()
                for (i in 0 until value.length()) out.put(sanitizeJson(value.opt(i)))
                out
            }
            else -> value
        }
    }

    private fun appendProtocolFieldInventory(o: JSONObject, roundId: String, now: Long, seq: Long) {
        ensureFile(protocolFieldLogFileName,
            "round_id,event_time,seq,cmd,field_path,field_type,field_class,field_value")
        val cmd = o.optInt("cmd", -1)
        val flattened = mutableListOf<Pair<String, String>>()
        appendFlattenedFields(o, "", flattened)
        val eventTime = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date(now))
        val batch = StringBuilder()
        flattened.forEach { (path, rawValue) ->
            val key = path.substringAfterLast('.')
            val safeValue = if (isAuthSensitiveKey(key)) "[REDACTED_AUTH_FIELD]" else rawValue.take(4000)
            val type = when {
                rawValue == "null" || rawValue.isBlank() -> "null_or_empty"
                rawValue == "true" || rawValue == "false" -> "boolean"
                rawValue.toDoubleOrNull() != null -> "number"
                rawValue.startsWith("{") -> "object"
                rawValue.startsWith("[") -> "array"
                else -> "string"
            }
            batch.append(listOf(
                roundId, eventTime, seq.toString(), cmd.toString(), path, type, fieldClass(key), safeValue
            ).joinToString(",") { csvCell(it) }).append('\n')
        }
        if (batch.isNotEmpty()) appendLine(protocolFieldLogFileName, batch.toString().trimEnd('\n'))
    }

    private fun appendRoundProtocolEvent(roundId: String, now: Long, seq: Long, cmd: Int, sta: Int, mul: String, o: JSONObject) {
        ensureFile(roundProtocolLogFileName,
            "round_id,event_time,seq,cmd,sta,multiplier,pre_final,is_round_start_candidate,is_config_candidate,has_seed,has_hash,has_signature,field_names")
        val names = mutableListOf<String>()
        val keys = o.keys()
        while (keys.hasNext()) names.add(keys.next())
        val lower = names.map { it.lowercase(Locale.US) }
        val hasSeed = lower.any { it.contains("seed") || it.contains("nonce") }
        val hasHash = lower.any { it.contains("hash") || it.contains("sha") || it.contains("md5") || it.contains("digest") || it.contains("commit") }
        val hasSignature = lower.any { it.contains("signature") || it == "sig" }
        val isRoundStart = (cmd == 84 && (sta == 1 || sta == 0)) || lower.any { it == "roundstart" || it == "round_start" || it == "newround" }
        val isConfig = cmd == 81 || lower.any { it.contains("config") || it == "rs" || it == "rt" || it == "ts" }
        val line = listOf(
            roundId,
            SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date(now)),
            seq.toString(), cmd.toString(), sta.toString(), mul,
            if (cmd == 84 && sta == 3) "0" else "1",
            if (isRoundStart) "1" else "0",
            if (isConfig) "1" else "0",
            if (hasSeed) "1" else "0",
            if (hasHash) "1" else "0",
            if (hasSignature) "1" else "0",
            names.sorted().joinToString("|")
        ).joinToString(",") { csvCell(it) }
        appendLine(roundProtocolLogFileName, line)
    }

    private fun startCreateDocument(name: String, type: String, requestCode: Int) {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            this.type = type
            putExtra(Intent.EXTRA_TITLE, name)
        }
        startActivityForResult(intent, requestCode)
    }

    private fun findValueAt(points: List<LivePoint>, target: Long): Double? {
        if (points.isEmpty()) return null
        return points.minByOrNull { abs(it.timeMs - target) }?.multiplier
    }

    private fun slopeAround(points: List<LivePoint>, target: Long, window: Long): Double? {
        if (points.size < 2) return null
        val a = points.minByOrNull { abs(it.timeMs - (target - window)) } ?: return null
        val b = points.minByOrNull { abs(it.timeMs - target) } ?: return null
        if (b.timeMs <= a.timeMs) return null
        return (b.multiplier - a.multiplier) / ((b.timeMs - a.timeMs) / 1000.0)
    }

    private fun intervalStats(points: List<LivePoint>): Triple<Long?, Double?, Double?> {
        if (points.size < 2) return Triple(null, null, null)
        val ds = points.zipWithNext().map { (a,b) -> (b.timeMs-a.timeMs).toDouble() }.filter { it > 0 }
        if (ds.isEmpty()) return Triple(null,null,null)
        val mean = ds.average()
        val sd = kotlin.math.sqrt(ds.map { (it-mean)*(it-mean) }.average())
        return Triple(ds.last().toLong(), mean, sd)
    }


    private fun slopeAtThreshold(points: List<LivePoint>, threshold: Double): Double? {
        val hit = points.firstOrNull { it.multiplier >= threshold } ?: return null
        val target = hit.timeMs
        return slopeAround(points, target, 500L)
    }

    private fun trajectoryStats(points: List<LivePoint>): Pair<Double?, Double?> {
        val usable = points.filter { it.multiplier > 0.0 }
        if (usable.size < 3) return null to null
        val t0 = usable.first().timeMs
        val xs = usable.map { (it.timeMs - t0) / 1000.0 }
        val ys = usable.map { ln(it.multiplier) }
        val xbar = xs.average()
        val ybar = ys.average()
        val denom = xs.sumOf { (it - xbar).pow(2) }
        if (denom <= 0.0) return null to null
        val beta = xs.zip(ys).sumOf { (it.first - xbar) * (it.second - ybar) } / denom
        val alpha = ybar - beta * xbar
        val rms = sqrt(ys.mapIndexed { i, y -> (y - (alpha + beta * xs[i])).pow(2) }.average())
        return rms to beta
    }

    private fun finishRound(roundId: String, finalMultiplier: Double, now: Long) {
        val start = currentRoundStartMs
        val duration = if (start > 0L) max(0L, now - start) else 0L
        val points = (currentTrajectory + LivePoint(now, finalMultiplier)).distinctBy { it.timeMs }.sortedBy { it.timeMs }
        fun before(ms: Long) = findValueAt(points, now - ms)
        fun thresholdMs(threshold: Double): Long? {
            val p = points.firstOrNull { it.multiplier >= threshold } ?: return null
            return max(0L, now - p.timeMs)
        }
        val slope1 = slopeAround(points, now - 1000L, 500L)
        val prevSlope = slopeAround(points, now - 2000L, 500L)
        val intervals = intervalStats(points)
        val prior = rounds.mapNotNull { it.multiplier.toDoubleOrNull() }.take(MAX_HISTORY)
        val medianPrior = prior.sorted().let { s -> if (s.isEmpty()) null else if (s.size % 2 == 1) s[s.size / 2] else (s[s.size / 2 - 1] + s[s.size / 2]) / 2.0 }
        val lowStreak = prior.takeWhile { it < 1.5 }.size
        val highStreak = prior.takeWhile { it >= 5.0 }.size
        val shortStreak = prior.takeWhile { it < 2.0 }.size
        val trajectory = trajectoryStats(points)
        val row = FeatureRow(
            roundId, finalMultiplier, duration, points.size, before(3000L), before(2000L), before(1000L), before(500L), before(250L),
            slopeAround(points, now - 3000L, 500L), prevSlope, slope1, slopeAround(points, now - 500L, 250L),
            if (slope1 != null && prevSlope != null) slope1 - prevSlope else null,
            intervals.first, intervals.second, intervals.third, points.count { it.timeMs >= now - 2000L }, points.filter { it.timeMs < now }.maxOfOrNull { it.multiplier },
            thresholdMs(1.1), thresholdMs(1.2), thresholdMs(1.5), thresholdMs(2.0), thresholdMs(3.0), thresholdMs(5.0), thresholdMs(10.0),
            if (finalMultiplier < 1.5) 1 else 0, if (finalMultiplier < 2.0) 1 else 0, if (finalMultiplier < 3.0) 1 else 0,
            prior.getOrNull(0), prior.getOrNull(1), prior.getOrNull(2), prior.getOrNull(3), prior.getOrNull(4),
            prior.getOrNull(5), prior.getOrNull(6), prior.getOrNull(7), prior.getOrNull(8), prior.getOrNull(9),
            lowStreak, highStreak, shortStreak, if (prior.isEmpty()) null else prior.average(), medianPrior,
            trajectory.first, trajectory.second,
            slopeAtThreshold(points, 1.2), slopeAtThreshold(points, 1.5), slopeAtThreshold(points, 2.0), slopeAtThreshold(points, 3.0)
        )
        featureRows.removeAll { it.roundId == roundId }
        featureRows.add(row)
        if (featureRows.size > 10000) featureRows.removeAt(0)
        ensureEventAndFeatureFiles()
        val values = listOf(row.roundId,row.finalMultiplier,row.durationMs,row.eventCount,row.at3sBefore,row.at2sBefore,row.at1sBefore,row.at05sBefore,row.at025sBefore,
            row.slope3s,row.slope2s,row.slope1s,row.slope05s,row.acceleration1s,row.lastIntervalMs,row.meanIntervalMs,row.sdIntervalMs,row.eventsLast2s,row.maxPreCrashMultiplier,
            row.msFrom1_1xToCrash,row.msFrom1_2xToCrash,row.msFrom1_5xToCrash,row.msFrom2xToCrash,row.msFrom3xToCrash,row.msFrom5xToCrash,row.msFrom10xToCrash,
            row.targetLt15,row.targetLt20,row.targetLt30,row.prev1,row.prev2,row.prev3,row.prev4,row.prev5,row.prev6,row.prev7,row.prev8,row.prev9,row.prev10,
            row.lowStreakLt15,row.highStreakGe5,row.shortStreakLt2,row.meanPrev10,row.medianPrev10,row.trajectoryRmsResidual,row.logGrowthRate,
            row.slopeAt1_2x,row.slopeAt1_5x,row.slopeAt2x,row.slopeAt3x)
        appendLine(featureLogFileName, values.joinToString(",") { csvCell(it?.toString() ?: "") })
    }

    private fun updateTestSignal(now: Long) {
        if (currentRoundId.isBlank() || currentRoundStartMs <= 0L) return
        val elapsed = now - currentRoundStartMs
        if (elapsed < 2500L) {
            signalView.text = "TEST SIGNAL • collecting baseline…"
            signalView.setTextColor(Color.rgb(70, 80, 90))
            return
        }
        val oneSec = now - 1000L
        val recent = synchronized(signalEvents) { signalEvents.filter { it.first >= oneSec } }
        val c85 = recent.count { it.second == 85 }
        val c88 = recent.count { it.second == 88 }
        // Experimental candidate from the 391-round study: unusually low live-update
        // activity. This is intentionally a hint only; it is not a validated predictor.
        val candidate = c85 <= 7
        if (candidate) {
            signalView.text = "🔴 TEST HINT • LOW ACTIVITY (cmd85=$c85, cmd88=$c88) • unvalidated"
            signalView.setTextColor(Color.rgb(175, 45, 45))
        } else {
            signalView.text = "🟢 TEST SIGNAL • normal activity (cmd85=$c85, cmd88=$c88)"
            signalView.setTextColor(Color.rgb(35, 120, 70))
        }
    }

    inner class Bridge {
        @JavascriptInterface
        fun event(raw: String) {
            runOnUiThread {
                try {
                    count++
                    val o = JSONObject(raw)
                    val cmd = o.optInt("cmd", -1)
                    val sta = o.optInt("sta", -1)
                    val mul = o.optString("mul", "")
                    val rbd = o.optString("rbd", "")
                    val now = System.currentTimeMillis()

                    if (rbd.isNotBlank() && rbd != currentRoundId && cmd != 102) {
                        currentRoundId = rbd
                        currentRoundStartMs = now
                        currentTrajectory.clear()
                        currentEvents = 0
                        synchronized(signalEvents) { signalEvents.clear() }
                        signalView.text = "TEST SIGNAL • round $rbd starting"
                        signalView.setTextColor(Color.rgb(70, 80, 90))
                    }

                    synchronized(signalEvents) {
                        if (cmd >= 0) signalEvents.add(now to cmd)
                        val cutoff = now - 5000L
                        while (signalEvents.isNotEmpty() && signalEvents.first().first < cutoff) signalEvents.removeAt(0)
                    }

                    val eventRoundId = if (rbd.isNotBlank()) rbd else currentRoundId
                    if (cmd == 85 && mul.toDoubleOrNull() != null) {
                        val value = mul.toDouble()
                        if (currentRoundId.isBlank()) currentRoundId = eventRoundId
                        currentTrajectory.add(LivePoint(now, value))
                        if (currentTrajectory.size > 4000) currentTrajectory.removeAt(0)
                        currentMultiplier = mul
                        currentEvents++
                    }

                    updateTestSignal(now)

                    val eventTime = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.US).format(Date(now))
                    val elapsed = if (currentRoundStartMs > 0L) max(0L, now - currentRoundStartMs) else 0L
                    packetSeq++

                    if (cmd >= 0 || o.has("lab")) {
                        ensureFile(eventLogFileName, "round_id,event_time,elapsed_ms,seq,cmd,sta,multiplier,is_final,selected_payload")
                        val selected = sanitizeJson(o)?.toString() ?: "{}"
                        val line = listOf(
                            eventRoundId, eventTime, elapsed.toString(), packetSeq.toString(), cmd.toString(),
                            sta.toString(), mul, if (cmd == 84 && sta == 3) "1" else "0", selected
                        ).joinToString(",") { csvCell(it) }
                        appendLine(eventLogFileName, line)
                        appendProtocolFieldInventory(o, eventRoundId, now, packetSeq)
                        if (cmd >= 0) appendRoundProtocolEvent(eventRoundId, now, packetSeq, cmd, sta, mul, o)
                    }

                    if (cmd == 84 && sta == 3 && rbd.isNotBlank() && mul.isNotBlank()) {
                        val final = mul.toDoubleOrNull()
                        if (final != null) finishRound(rbd, final, now)
                        addOrUpdateCompletedRound(rbd, mul)
                        currentMultiplier = mul
                        status.text = "✓ Round $rbd completed at ${mul}×"
                        renderUi()
                    } else {
                        status.text = "Live • ${if (currentMultiplier.isBlank()) "—" else currentMultiplier + "×"} • $eventRoundId"
                        renderUi()
                    }
                } catch (_: Exception) {}
            }
        }
    }

    override fun onDestroy() {
        try { stopService(Intent(this, CollectorKeepAliveService::class.java)) } catch (_: Exception) {}
        io.shutdownNow()
        web.destroy()
        super.onDestroy()
    }

    @Deprecated("Deprecated API retained for broad device compatibility.")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri: Uri = data?.data ?: return
        if (requestCode == 7006) {
            val zip = pendingAllZip
            if (zip == null || !zip.exists()) { status.text = "Export ZIP is missing."; return }
            try {
                contentResolver.openOutputStream(uri)?.use { out -> zip.inputStream().use { it.copyTo(out) } }
                status.text = "EXPORT ALL complete — one ZIP file saved."
            } catch (_: Exception) {
                status.text = "EXPORT ALL failed while saving ZIP."
            } finally {
                pendingAllZip = null
            }
            return
        }
        val payload = when (requestCode) {
            7001 -> pendingCsv
            7002 -> pendingEventCsv
            7003 -> pendingFeatureCsv
            7004 -> pendingProtocolCsv
            7005 -> pendingRoundProtocolCsv
            else -> ""
        }
        if (payload.isBlank()) return
        try {
            contentResolver.openOutputStream(uri)?.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
            status.text = "Export complete."
        } catch (_: Exception) {
            status.text = "Export failed."
        } finally {
            pendingCsv = ""
            pendingEventCsv = ""
            pendingFeatureCsv = ""
            pendingProtocolCsv = ""
            pendingRoundProtocolCsv = ""
        }
    }
}
