package com.example.aviatorbrowserlab

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(12,12,12,12) }
        val url = EditText(this).apply { setSingleLine(true); hint = "Game URL"; setText("https://99pakgame.com/") }
        val open = Button(this).apply { text = "OPEN GAME" }
        status = TextView(this).apply { text = "Waiting…"; setTextColor(Color.DKGRAY); setPadding(4,8,4,8) }
        web = WebView(this)
        root.addView(url, LinearLayout.LayoutParams(-1, -2))
        root.addView(open, LinearLayout.LayoutParams(-1, -2))
        root.addView(status, LinearLayout.LayoutParams(-1, -2))
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        val s: WebSettings = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.databaseEnabled = true
        s.setSupportMultipleWindows(false)
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                injectAviatorHook(view)
            }
        }
        web.webChromeClient = WebChromeClient()
        web.addJavascriptInterface(Bridge(), "AviatorBridge")
        open.setOnClickListener { web.loadUrl(url.text.toString()) }
        web.loadUrl(url.text.toString())
    }

    private fun injectAviatorHook(view: WebView) {
        val js = """
        (function(){
          if(window.__aviatorHooked) return; window.__aviatorHooked=true;
          function report(x){ try{ window.AviatorBridge.event(JSON.stringify(x)); }catch(e){} }
          const OldWS = window.WebSocket;
          window.WebSocket = function(url, protocols){
            const ws = protocols === undefined ? new OldWS(url) : new OldWS(url, protocols);
            ws.addEventListener('message', function(ev){
              try{
                const d = typeof ev.data === 'string' ? JSON.parse(ev.data) : null;
                if(d && (d.cmd===85 || d.cmd===84 || d.cmd===88)) report(d);
              }catch(e){}
            });
            return ws;
          };
          window.WebSocket.prototype = OldWS.prototype;
          window.WebSocket.CONNECTING=OldWS.CONNECTING; window.WebSocket.OPEN=OldWS.OPEN;
          window.WebSocket.CLOSING=OldWS.CLOSING; window.WebSocket.CLOSED=OldWS.CLOSED;
        })();
        """.trimIndent()
        view?.evaluateJavascript(js, null)
    }

    inner class Bridge {
        @JavascriptInterface fun event(raw: String) {
            runOnUiThread {
                try {
                    val o = JSONObject(raw)
                    val cmd = o.optInt("cmd", -1)
                    val mul = o.optString("mul", "")
                    val rbd = o.optString("rbd", "")
                    status.text = "cmd=$cmd  multiplier=${if (mul.isBlank()) "-" else mul + "x"}  round=$rbd"
                } catch (_: Exception) { }
            }
        }
    }
}
