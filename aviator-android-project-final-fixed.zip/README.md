# Aviator Android Lab

Android WebView research client for observing game messages that are exposed to the page.

The app automatically hooks the page's WebSocket constructor and reports JSON events with cmd 84, 85, or 88 when the page exposes them to JavaScript.

It does not request passwords, OTPs, cookies, auth tokens, or payment information, and it does not place or modify bets.

Important: Android WebView cannot guarantee visibility into every WebSocket implementation. If the game's connection is created in a worker, native layer, or otherwise hidden from page JavaScript, this hook may not see it.
