# Aviator Android Lab 1.5

Observation/research wrapper for the user-provided game site.

Changes in 1.5:
- Enables Android cleartext traffic for legacy HTTP API dependencies.
- Redacts query strings from URLs shown in the app.
- Adds fetch/XHR HTTP and network diagnostics without recording request bodies, passwords, cookies, or auth tokens.
- Retains completed-round storage and CSV export.
- Retains WebSocket observation of cmd 84/85/88.

This does not alter bets or bypass authentication.
